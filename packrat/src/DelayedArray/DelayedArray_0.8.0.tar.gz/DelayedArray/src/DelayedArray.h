#include <Rdefines.h>


/* abind.c */

SEXP abind(SEXP objects, SEXP nblock, SEXP ans_dim);

