###

test_relistToClass <- function()
{
    ## TODO
}

test_relist <- function()
{
    ## TODO
}

test_splitAsList <- function()
{
    ## TODO
}

test_extractList <- function()
{
    ## TODO
}

