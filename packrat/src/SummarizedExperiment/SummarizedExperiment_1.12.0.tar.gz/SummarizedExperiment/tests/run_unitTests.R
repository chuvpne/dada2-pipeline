require("SummarizedExperiment") || stop("unable to load SummarizedExperiment package")
SummarizedExperiment:::.test()
