library(testthat)
library(dygraphs)
library(datasets)

test_check("dygraphs")
