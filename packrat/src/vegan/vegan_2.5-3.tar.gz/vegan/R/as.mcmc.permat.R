`as.mcmc.permat` <- as.mcmc.oecosimu
