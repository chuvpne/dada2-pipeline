`deviance.cca` <-
    function(object, ...)
{
    object$CA$tot.chi * object$grand.tot
}
