"estimateR.data.frame" <-
function(x, ...) apply(x, 1, estimateR, ...)
