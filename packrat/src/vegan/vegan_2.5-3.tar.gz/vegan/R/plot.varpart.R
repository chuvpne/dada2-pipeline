"plot.varpart" <-
function(x, ...)
{
    plot(x$part, ...)
    invisible()
}

